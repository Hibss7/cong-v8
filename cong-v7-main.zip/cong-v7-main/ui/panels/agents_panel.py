# Fichier : ui/panels/agents_panel.py
# VERSION FINALE - Ajout du bouton de suppression définitive et logique de sélection standard.

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

from core.constants import SoldeStatus
from ui.forms.agent_form import AgentForm
from ui.ui_utils import treeview_sort_column
from utils.file_utils import export_agents_to_excel, import_agents_from_excel
from ui.agent_profile_window import AgentProfileWindow

class AgentsPanel(ttk.Frame):
    def __init__(self, parent_widget, main_app, manager, base_dir, on_agent_select_callback):
        super().__init__(parent_widget, padding=5)
        self.main_app = main_app
        self.manager = manager
        self.base_dir = base_dir
        self.on_agent_select_callback = on_agent_select_callback

        self.annee_exercice = self.manager.get_annee_exercice()
        
        self.current_page = 1
        self.items_per_page = 50
        self.total_pages = 1
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.search_agents())
        self.status_filter_var = tk.StringVar(value="Actif")

        self._create_widgets()
        self.refresh_agents_list()

    def _create_widgets(self):
        agents_frame = ttk.LabelFrame(self, text="Agents")
        agents_frame.pack(fill=tk.BOTH, expand=True)

        top_bar_frame = ttk.Frame(agents_frame)
        top_bar_frame.pack(fill=tk.X, padx=5, pady=5)

        filter_frame = ttk.Frame(top_bar_frame)
        filter_frame.pack(side=tk.LEFT, padx=(0, 20))
        ttk.Radiobutton(filter_frame, text="Agents Actifs", variable=self.status_filter_var, value="Actif", command=self._on_filter_change).pack(anchor='w')
        ttk.Radiobutton(filter_frame, text="Agents Archivés", variable=self.status_filter_var, value="Archivé", command=self._on_filter_change).pack(anchor='w')

        search_frame = ttk.Frame(top_bar_frame)
        search_frame.pack(fill=tk.X, expand=True, side=tk.LEFT)
        ttk.Label(search_frame, text="Rechercher:").pack(side=tk.LEFT, padx=(0, 5))
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        self.search_entry.pack(fill=tk.X, expand=True, side=tk.LEFT)
        
        an_n, an_n1, an_n2 = self.annee_exercice, self.annee_exercice - 1, self.annee_exercice - 2
        self.cols_agents = ["ID", "Nom", "Prénom", "PPR", "Cadre", f"Solde {an_n2}", f"Solde {an_n1}", f"Solde {an_n}", "Solde Total"]
        
        self.list_agents = ttk.Treeview(agents_frame, columns=self.cols_agents, show="headings", selectmode="extended")
        
        for col in self.cols_agents:
            self.list_agents.heading(col, text=col, command=lambda c=col: treeview_sort_column(self.list_agents, c, False))
        
        self.list_agents.column("ID", width=0, stretch=False)
        self.list_agents.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.list_agents.bind("<<TreeviewSelect>>", self._on_agent_select)
        self.list_agents.bind("<Double-1>", lambda e: self.open_agent_profile())

        pagination_frame = ttk.Frame(agents_frame); pagination_frame.pack(fill=tk.X, padx=5, pady=5)
        self.prev_button = ttk.Button(pagination_frame, text="<< Précédent", command=self.prev_page); self.prev_button.pack(side=tk.LEFT)
        self.page_label = ttk.Label(pagination_frame, text="Page 1 / 1"); self.page_label.pack(side=tk.LEFT, expand=True)
        self.next_button = ttk.Button(pagination_frame, text="Suivant >>", command=self.next_page); self.next_button.pack(side=tk.RIGHT)
        
        self.actions_frame = ttk.Frame(agents_frame); self.actions_frame.pack(fill=tk.X, padx=5, pady=(0, 5))
        self.io_frame_agents = ttk.Frame(agents_frame); self.io_frame_agents.pack(fill=tk.X, padx=5, pady=(5, 5))
        
        self._update_action_buttons()

        ttk.Button(self.io_frame_agents, text="Importer Agents (Excel)", command=self.import_agents).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        ttk.Button(self.io_frame_agents, text="Exporter Agents (Excel)", command=self.export_agents).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)

    def _on_filter_change(self):
        self.refresh_agents_list()
        self._update_action_buttons()

    def _update_action_buttons(self):
        for widget in self.actions_frame.winfo_children():
            widget.destroy()

        is_archived_view = self.status_filter_var.get() == 'Archivé'
        
        ttk.Button(self.actions_frame, text="Fiche de renseignement", command=self.open_agent_profile).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        
        add_btn_state = "disabled" if is_archived_view else "normal"
        modify_btn_state = "disabled" if is_archived_view else "normal"

        ttk.Button(self.actions_frame, text="Ajouter", command=self.add_agent_ui, state=add_btn_state).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        ttk.Button(self.actions_frame, text="Modifier", command=self.modify_agent_ui, state=modify_btn_state).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)

        if is_archived_view:
            ttk.Button(self.actions_frame, text="Restaurer", command=self._restore_selected_agents).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
            ttk.Button(self.actions_frame, text="Supprimer Définitivement", command=self._delete_selected_agents_permanently).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        else:
            ttk.Button(self.actions_frame, text="Archiver", command=self._archive_selected_agents).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)

    def _archive_selected_agents(self):
        selected_ids = self.get_selected_agent_ids()
        if not selected_ids:
            messagebox.showwarning("Aucune sélection", "Veuillez sélectionner au moins un agent à archiver.", parent=self)
            return

        if len(selected_ids) == 1:
            agent = self.manager.get_agent_by_id(selected_ids[0])
            message = f"Voulez-vous vraiment archiver l'agent '{agent.nom} {agent.prenom}' ?"
        else:
            message = f"Voulez-vous vraiment archiver les {len(selected_ids)} agents sélectionnés ?"

        if messagebox.askyesno("Confirmation d'archivage", message, parent=self):
            self.manager.archive_agents(selected_ids)
            self.main_app.refresh_all()
    
    def _restore_selected_agents(self):
        selected_ids = self.get_selected_agent_ids()
        if not selected_ids:
            messagebox.showwarning("Aucune sélection", "Veuillez sélectionner au moins un agent à restaurer.", parent=self)
            return

        if len(selected_ids) == 1:
            agent = self.manager.get_agent_by_id(selected_ids[0])
            message = f"Voulez-vous vraiment restaurer l'agent '{agent.nom} {agent.prenom}' ?"
        else:
            message = f"Voulez-vous vraiment restaurer les {len(selected_ids)} agents sélectionnés ?"

        if messagebox.askyesno("Confirmation de restauration", message, parent=self):
            self.manager.restore_agents(selected_ids)
            self.main_app.refresh_all()

    def _delete_selected_agents_permanently(self):
        selected_ids = self.get_selected_agent_ids()
        if not selected_ids:
            messagebox.showwarning("Aucune sélection", "Veuillez sélectionner au moins un agent à supprimer.", parent=self)
            return

        if len(selected_ids) == 1:
            agent = self.manager.get_agent_by_id(selected_ids[0])
            message = f"Vous êtes sur le point de supprimer définitivement l'agent '{agent.nom} {agent.prenom}'."
        else:
            message = f"Vous êtes sur le point de supprimer définitivement {len(selected_ids)} agents."
        
        final_message = message + "\nToutes leurs données (congés, historique...) seront perdues.\n\nATTENTION : CETTE ACTION EST IRRÉVERSIBLE.\n\nÊtes-vous absolument certain de vouloir continuer ?"

        if messagebox.askyesno("Confirmation de Suppression Définitive", final_message, icon='warning', parent=self):
            self.manager.delete_agents_permanently(selected_ids)
            self.main_app.refresh_all()

    def open_agent_profile(self):
        selected_ids = self.get_selected_agent_ids()
        if len(selected_ids) == 1: AgentProfileWindow(self.main_app, self.manager, selected_ids[0])
        else: messagebox.showwarning("Sélection", "Veuillez sélectionner un seul agent.", parent=self)

    def get_selected_agent_ids(self):
        return [int(self.list_agents.item(item_id)["values"][0]) for item_id in self.list_agents.selection()]

    def refresh_agents_list(self, agent_to_select_id=None):
        for row in self.list_agents.get_children(): self.list_agents.delete(row)
        
        statut = self.status_filter_var.get()
        term = self.search_var.get().strip().lower() or None
        total_items = self.manager.get_agents_count(statut, term)
        self.total_pages = max(1, (total_items + self.items_per_page - 1) // self.items_per_page)
        self.current_page = min(self.current_page, self.total_pages)
        offset = (self.current_page - 1) * self.items_per_page
        
        agents = self.manager.get_all_agents(statut=statut, term=term, limit=self.items_per_page, offset=offset)
        
        an_n, an_n1, an_n2 = self.annee_exercice, self.annee_exercice - 1, self.annee_exercice - 2
        
        item_to_select = None
        for agent in agents:
            soldes_par_annee = {s.annee: s.solde for s in agent.soldes_annuels if s.statut == SoldeStatus.ACTIF}
            solde_total = agent.get_solde_total_actif()

            solde_n2_display = f"{soldes_par_annee.get(an_n2, 0.0):.1f} j"
            solde_n1_display = f"{soldes_par_annee.get(an_n1, 0.0):.1f} j"
            solde_n_display = f"{soldes_par_annee.get(an_n, 0.0):.1f} j"
            solde_total_display = f"{solde_total:.1f} j"

            values = (agent.id, agent.nom, agent.prenom, agent.ppr, agent.cadre, 
                      solde_n2_display, solde_n1_display, solde_n_display, solde_total_display)
            
            item_id = self.list_agents.insert("", "end", values=values)
            if agent_to_select_id is not None and agent.id == agent_to_select_id:
                item_to_select = item_id

        if item_to_select:
            self.list_agents.selection_set(item_to_select)
            self.list_agents.see(item_to_select)
        
        self.page_label.config(text=f"Page {self.current_page} / {self.total_pages}")
        self.prev_button.config(state="normal" if self.current_page > 1 else "disabled")
        self.next_button.config(state="normal" if self.current_page < self.total_pages else "disabled")
        self.main_app.set_status(f"{len(agents)} agents affichés sur {total_items} au total.")

    def search_agents(self):
        self.current_page = 1; self.refresh_agents_list()

    def prev_page(self):
        if self.current_page > 1: self.current_page -= 1; self.refresh_agents_list()

    def next_page(self):
        if self.current_page < self.total_pages: self.current_page += 1; self.refresh_agents_list()

    def _on_agent_select(self, event=None):
        selected_ids = self.get_selected_agent_ids()
        agent_id_for_conges = selected_ids[0] if len(selected_ids) == 1 else None
        self.on_agent_select_callback(agent_id_for_conges)

    def add_agent_ui(self):
        AgentForm(self.main_app, self.manager)
        
    def modify_agent_ui(self):
        selected_ids = self.get_selected_agent_ids()
        if len(selected_ids) == 1: AgentForm(self.main_app, self.manager, agent_id_to_modify=selected_ids[0])
        else: messagebox.showwarning("Sélection", "Veuillez sélectionner un seul agent à modifier.", parent=self)

    def import_agents(self):
        source_path = filedialog.askopenfilename(title="Importer (Excel)", filetypes=[("Fichiers Excel", "*.xlsx")])
        if not source_path: return
        db_path = self.manager.db.get_db_path()
        cert_path = self.manager.certificats_dir
        self.main_app._run_long_task(lambda: import_agents_from_excel(db_path, cert_path, source_path), self.main_app._on_import_complete, "Importation...")

    def export_agents(self):
        save_path = filedialog.asksaveasfilename(title="Exporter (Excel)", defaultextension=".xlsx", initialfile=f"Export_Agents_{datetime.now():%Y-%m-%d}.xlsx")
        if not save_path: return
        db_path = self.manager.db.get_db_path()
        cert_path = self.manager.certificats_dir
        self.main_app._run_long_task(lambda: export_agents_to_excel(db_path, cert_path, save_path), self.main_app._on_task_complete, "Exportation...")

    def toggle_buttons_state(self, state):
        is_normal = state == "normal"
        # On ne désactive que les boutons d'import/export
        for child in self.io_frame_agents.winfo_children():
            if isinstance(child, ttk.Button): child.config(state=state)
        self.search_entry.config(state=state)
        # La barre d'actions principale n'est pas affectée par les tâches longues
        # pour permettre à l'utilisateur de continuer à naviguer.